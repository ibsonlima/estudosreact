import React from 'react';
import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';
import DashboardIcon from '@material-ui/icons/Dashboard';
import AddIcon from '@material-ui/icons/Add';

//Import Redux
import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'
import { setHomeRender } from '../../actions'

const MainListItems = (props) =>{

  const createRqHandle = ()=>{
    props.setHomeRender(1)
  }
  
  const homeHandle = ()=>{
    props.setHomeRender(0)
  }

  return (
    <div>
      <ListItem button onClick={homeHandle}>
        <ListItemIcon>
          <DashboardIcon />
        </ListItemIcon>
        <ListItemText primary="Página inicial" />
      </ListItem>
      <ListItem button onClick={createRqHandle}>
        <ListItemIcon>
          <AddIcon />
        </ListItemIcon>
        <ListItemText primary="Criar nova RQ" />
      </ListItem>
      <ListItem button>
        <ListItemIcon>
          <DashboardIcon />
        </ListItemIcon>
        <ListItemText primary="Dashboard" />
      </ListItem>
    </div>
  )
  
};


const mapStateToProps = store => ({
  
})
const mapActionToProps = dispatch => (
  bindActionCreators({ setHomeRender }, dispatch)
)

export default connect(mapStateToProps, mapActionToProps)(MainListItems)
import React, { useState } from 'react'
import { makeStyles } from '@material-ui/core/styles';
import CssBaseline from '@material-ui/core/CssBaseline';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import Paper from '@material-ui/core/Paper';
import TextField from '@material-ui/core/TextField';
import 'date-fns';
import DateFnsUtils from '@date-io/date-fns';
import Grid from '@material-ui/core/Grid';
import { ptBR } from 'date-fns/locale'
import DeleteIcon from '@material-ui/icons/Delete';
import SaveIcon from '@material-ui/icons/Save';
import Button from '@material-ui/core/Button';
import {
  MuiPickersUtilsProvider,
  KeyboardTimePicker,
  KeyboardDatePicker,
} from '@material-ui/pickers';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';

import FormLabel from '@material-ui/core/FormLabel';
import FormControl from '@material-ui/core/FormControl';
import FormGroup from '@material-ui/core/FormGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import FormHelperText from '@material-ui/core/FormHelperText';
import Switch from '@material-ui/core/Switch';

import clsx from 'clsx';
import CheckCircleIcon from '@material-ui/icons/CheckCircle';
import Snackbar from '@material-ui/core/Snackbar';
import SnackbarContent from '@material-ui/core/SnackbarContent';
import { green } from '@material-ui/core/colors';
import IconButton from '@material-ui/core/IconButton';
import CloseIcon from '@material-ui/icons/Close';
//import Firebase 

import firebase from '../../firabase'
//Import Redux
import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'
import { setHomeRender } from '../../actions'

const useStyles = makeStyles(theme => ({
  success: {
    backgroundColor: green[600],
  },
  icon: {
    fontSize: 20,
  },
  iconVariant: {
    opacity: 0.9,
    marginRight: theme.spacing(1),
  },
  message: {
    display: 'flex',
    alignItems: 'center',
  },
  container: {
    display: 'flex',
    flexWrap: 'wrap',
  },
  textFieldLine: {
      marginLeft: theme.spacing(1),
      marginRight: theme.spacing(1),
      width: "47%",
  },
  input: {
    margin: theme.spacing(1),
  },
  appBar: {
      position: 'relative',
    },
    layout: {
      width: 'auto',
      marginLeft: theme.spacing(2),
      marginRight: theme.spacing(2),
      [theme.breakpoints.up(600 + theme.spacing(2) * 2)]: {
        width: 600,
        marginLeft: 'auto',
        marginRight: 'auto',
      },
      
    },
    paper: {
      marginTop: theme.spacing(3),
      marginBottom: theme.spacing(3),
      padding: theme.spacing(2),
      [theme.breakpoints.up(600 + theme.spacing(3) * 2)]: {
        marginTop: theme.spacing(6),
        marginBottom: theme.spacing(6),
        padding: theme.spacing(3),
      },
    },
    button: {
      margin: theme.spacing(1),
    },
  switch: {
    marginLeft: theme.spacing(1),
    marginRight: theme.spacing(1),
}
}));
  
function Create(props) {
  const classes = useStyles();
  const initialState = {
    modalidade: false,
    abertura: null
  }
  const [state, setState] = useState(initialState);
  const [open, setOpen] = React.useState(false);
  const [openSnack, SetOpenSnack] = React.useState(false);

  const handleClickOpen = (e) => { //Open dialog
    e.preventDefault()
    setOpen(true);
  };

  const handleClose = () => { //Close dialog
    setOpen(false);
  };

  const homeHandle = ()=>{ //Back to Home
    props.setHomeRender(0)
  }
  const snackHandleClose = ()=>{
    SetOpenSnack(false)
  }
  const snackHandleOpen = ()=>{
    SetOpenSnack(true)
  }

  const handleSwitch = () => {
    let value = !state.modalidade
    setState({
      ...state,
      modalidade: value
    })
  }

  const modalidadeToString = (value) => {
    if(!value){
      return "Pregão Presencial"
    }else{
      return "Pregão Eletrônico"
    }
  }
  const handleDateChange = date => {
    setState({
      ...state,
      abertura: new Date(date),
      });
  };

  const onChangeValue = e => {
    const { name, value } = e.target
    let json = {...state}
    json[name] = value
    setState(json)
  }
  const submit = async () => {
    let db = firebase.firestore().collection('rqs').doc()
    let data = {
      ...state,
      modalidade: modalidadeToString(state.modalidade)
    }
    await db.set(data)
    document.querySelector('#form').reset()
    setState(initialState)
    handleClose()
    snackHandleOpen()
  }
  
  const showDate = (value) => {
    let date = new Date(value)
    let dateTime = date.toLocaleTimeString('pt-br')
    return `${date.toLocaleDateString('pt-br')} às ${dateTime.slice(0,dateTime.length-3)}`
  }

  return (
      <React.Fragment>
      <CssBaseline />
      <AppBar position="absolute" color="default" className={classes.appBar}>
        <Toolbar>
          <Typography variant="h6" color="inherit" noWrap>
            Criar Nova RQ-002
          </Typography>
        </Toolbar>
      </AppBar>
      <main className={classes.layout}>
          <Paper className={classes.paper}>
                  <form id="form"  className={classes.container} onSubmit={handleClickOpen}>
                    <TextField
                    id="orgaoNome"
                    label="Orgão"
                    name="orgao"
                    style={{ margin: 8 }}
                    placeholder="Digite o nome do orgão"
                    required
                    fullWidth
                    margin="normal"
                    InputLabelProps={{
                        shrink: true,
                    }}
                    onChange={onChangeValue}
                    />
                    <TextField
                    label="Numero do processo"
                    id="processoNumero"
                    name="numeroDoProcesso"
                    className={classes.textFieldLine}
                    required
                    onChange={onChangeValue}
                    />
                    <TextField
                    label="Numero do pregao"
                    id="pregaoNumero"
                    name="numeroDoPregao"
                    className={classes.textFieldLine}
                    required
                    onChange={onChangeValue}
                    />
                    <MuiPickersUtilsProvider utils={DateFnsUtils} locale={ptBR}>
                      <KeyboardDatePicker
                        margin="normal"
                        id="aberturaData"
                        name="aberturaData"
                        label="Data da abertura"
                        format="dd/MM/yyyy"
                        value={state.abertura}
                        onChange={handleDateChange}
                        KeyboardButtonProps={{
                          'aria-label': 'change date',
                        }}
                        className={classes.textFieldLine}
                        required
                      />
                      <KeyboardTimePicker
                        margin="normal"
                        id="aberturaHora"
                        name="aberturaHora"
                        label="Horário da abertura"
                        value={state.abertura}
                        onChange={handleDateChange}
                        KeyboardButtonProps={{
                          'aria-label': 'change time',
                        }}
                        className={classes.textFieldLine}
                        required
                      />
                    </MuiPickersUtilsProvider>
                    <Grid
                    container
                    direction="row"
                    justify="flex-end"
                    alignItems="center"
                    spacing={3}>
                      <Grid item xs={6} align='left'>
                        <FormControl component="fieldset" className={classes.switch}>
                          <FormLabel component="legend">Modalidade do pregão</FormLabel>
                          <FormGroup>
                            <FormControlLabel
                              control={<Switch checked={state.modalidade} onChange={handleSwitch} value={modalidadeToString(state.modalidade)}/>}
                              label={modalidadeToString(state.modalidade)} name="modalidade"
                            />
                          </FormGroup>
                          <FormHelperText>UltraMega Distribuidora hospitalar</FormHelperText>
                        </FormControl>
                      </Grid>
                      <Grid item xs={6}>
                      <div>
                        <Button
                            variant="contained"
                            color="primary"
                            size="medium"
                            name="aberturaHora"
                            className={classes.button}
                            startIcon={<SaveIcon />}
                            type="submit"
                          >Criar
                          </Button>
                          <Button
                            variant="contained"
                            color="secondary"
                            size="medium"
                            className={classes.button}
                            startIcon={<DeleteIcon />}
                            onClick={homeHandle}
                          >Cancelar
                          </Button>
                      </div>
                      </Grid>
                    </Grid>
                  </form>
          </Paper>
      </main>
        <div>
        <Dialog
          open={open}
          onClose={handleClose}
          aria-labelledby="alert-dialog-title"
          aria-describedby="alert-dialog-description"
        >
          <DialogTitle id="alert-dialog-title">{"Tem certeza que deseja salvar a RQ ?"}</DialogTitle>
          <DialogContent>
            <DialogContentText id="alert-dialog-description">
              {`Orgão: ${state.orgao}`} <br/>
              {`${modalidadeToString(state.modalidade)} Nº: ${state.numeroDoPregao}`} <br/>
              {`Processo licitatorio Nº: ${state.numeroDoProcesso}`} <br/>
              {`Abertura do pregão: ${showDate(state.abertura)}`}
            </DialogContentText>
          </DialogContent>
          <DialogActions>
            <Button onClick={handleClose} color="primary">
              Não
            </Button>
            <Button onClick={submit} color="primary" autoFocus>
              Sim
            </Button>
          </DialogActions>
        </Dialog>
      </div>
      <Snackbar
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'center',
        }}
        open={openSnack}
        autoHideDuration={6000}
        onClose={snackHandleClose}
      >
         <SnackbarContent
          className={clsx(classes.success)}
          aria-describedby="client-snackbar"
          message={
            <span id="client-snackbar" className={classes.message}>
              <CheckCircleIcon  className={classes.icon} />
              {`Nova RQ criada com sucesso !!`}
            </span>
          }
          action={[
            <IconButton key="close" aria-label="close" color="inherit" onClick={snackHandleClose}>
              <CloseIcon className={classes.icon} />
            </IconButton>,
          ]}
    />

      </Snackbar>
    </React.Fragment>
  );
}

const mapStateToProps = store => ({

})
const mapActionToProps = dispatch => (
  bindActionCreators({ setHomeRender }, dispatch)
)

export default connect(mapStateToProps, mapActionToProps)(Create)
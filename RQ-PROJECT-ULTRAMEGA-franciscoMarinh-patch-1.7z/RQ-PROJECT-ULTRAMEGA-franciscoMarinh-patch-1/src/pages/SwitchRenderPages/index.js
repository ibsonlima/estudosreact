import React from 'react'
import ActiveRqs from '../ActiveRqs'
import Create from '../Create'
import Edit from '../Edit'

function switchRenderPages(value, propsRqData = []){
    switch(value){
        case 0:
            return <ActiveRqs rqData={propsRqData}></ActiveRqs>
        case 1:
            return <Create></Create>
        case 2:
            return <Edit></Edit>
        default:
            return <div>Error</div>
    }
}

export default switchRenderPages
import React from 'react'
import Login from '../Login'
import Home from '../Home'
import { connect } from 'react-redux'


function switchInitialRender(value){
    switch(value){
        case 0:
            return <Login></Login>
        case 1:
            return <Home></Home>
        default:
            return <div>Error</div>
    }
}

function Main(props) {
    return (
        switchInitialRender(props.mainRender)
    )
}

const mapStateToProps = store => ({
    mainRender: store.mainReducer.mainRender,
})
  
export default connect(mapStateToProps)(Main)

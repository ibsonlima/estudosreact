/* eslint-disable no-script-url */
import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Box from '@material-ui/core/Box';
import Card from '@material-ui/core/Card';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import Button from '@material-ui/core/Button';
import Typography from '@material-ui/core/Typography';
import Grid from '@material-ui/core/Grid';
import Paper from '@material-ui/core/Paper';

// Generate Order Data

import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'
import { setHomeRender, setRqSelected } from '../../actions'

const useStyles = makeStyles(theme => ({
    card: {
      minWidth: 200,
      maxWidth: 300,
    },
    title: {
      fontSize: 14,
    },
    pos: {
      marginBottom: 12,
    },
    root: {
      flexGrow: 1,
    },
    paper: {
      padding: theme.spacing(2),
      textAlign: 'center',
      color: theme.palette.text.secondary,
    },
    layout: {
      width: 'auto',
      marginLeft: theme.spacing(2),
      marginRight: theme.spacing(2),
      [theme.breakpoints.up(600 + theme.spacing(2) * 2)]: {
        width: 680,
        marginLeft: 'auto',
        marginRight: 'auto',
        marginTop: "40px",
      },
      paper: {
        marginTop: theme.spacing(3),
        marginBottom: theme.spacing(3),
        padding: theme.spacing(2),
        [theme.breakpoints.up(600 + theme.spacing(3) * 2)]: {
          marginTop: theme.spacing(6),
          marginBottom: theme.spacing(6),
          padding: theme.spacing(3),
        },
      }
      
    }
  }));
  
  
function ActiveRqs(props) {
    const classes = useStyles();

    const showDate = (value) => {
      let date = new Date(value.seconds * 1000)
      let dateTime = date.toLocaleTimeString('pt-br')
      return `${date.toLocaleDateString('pt-br')} ás ${dateTime.slice(0,dateTime.length-3)}`
    }
    const editRq = (id) =>{
      const { setHomeRender, setRqSelected } = props
      setRqSelected(id)
      setHomeRender(2)
    }
      return(
        <React.Fragment>
          <main className={classes.layout}>
              <Paper className={classes.paper}>
              <div style={{ width: '100%' }}>
                <Box
                  display="flex"
                  flexWrap="wrap"
                  alignContent="center"
                  justifyContent="center"
                  bgcolor="background.paper"
                  css={{ maxWidth: true, height: true }}
                >
                  {props.rqData.map(el=> (
                    <Box m={1} bgcolor="grey.300" key={el.id} align="left">
                      <Card className={classes.card}>
                        <CardContent>
                          <Typography className={classes.title} color="textSecondary" gutterBottom align="left">
                            {el.orgao}
                          </Typography>
                          <Typography className={classes.title} color="textSecondary" gutterBottom align="left">
                            {`${el.modalidade} Nº: ${el.numeroDoPregao}`}
                          </Typography>
                          <Typography className={classes.title} color="textSecondary" gutterBottom align="left">
                          {`Processo Licitatorio Nº: ${el.numeroDoProcesso}`}
                          </Typography>
                          <Typography variant="body2" color="textSecondary" align="left">
                            {`Abertura: ${showDate(el.abertura)}`}
                          </Typography>
                          
                        </CardContent>
                        <div className={classes.root}>
                          <Grid container spacing={3}>
                            <Grid item xs={6}>
                              <Box display="flex" justifyContent="center">
                                <Box>
                                  <CardActions>
                                    <Button size="small">Visualizar</Button>
                                  </CardActions>
                                </Box>
                              </Box>
                            </Grid>
                            <Grid item xs={6}>
                              <Box display="flex" justifyContent="center">
                                  <Box>
                                    <CardActions>
                                      <Button size="small" onClick={() => editRq(el.id)}>Editar</Button>
                                    </CardActions>
                                  </Box>
                              </Box>
                            </Grid>
                          </Grid>
                        </div>
                      </Card>
                    </Box>
                  ))}
                  
                </Box>
              </div>
              </Paper>
          </main>
      </React.Fragment>
      )
  }
const mapStateToProps = store => ({

})
const mapActionToProps = dispatch => (
  bindActionCreators({ setHomeRender, setRqSelected }, dispatch)
)

export default connect(mapStateToProps, mapActionToProps)(ActiveRqs)
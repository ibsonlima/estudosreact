import React, { useEffect, useState, useReducer } from 'react'

import {
    MuiPickersUtilsProvider,
    KeyboardTimePicker,
    KeyboardDatePicker,
} from '@material-ui/pickers';
import { ptBR } from 'date-fns/locale'
import DateFnsUtils from '@date-io/date-fns';
import { makeStyles } from '@material-ui/core/styles';
import Paper from '@material-ui/core/Paper';
import TextField from '@material-ui/core/TextField';
import Typography from '@material-ui/core/Typography';
import EditIcon from '@material-ui/icons/Edit';
import { Dialog, Grid} from '@material-ui/core';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';

import DeleteIcon from '@material-ui/icons/Delete';
import SaveIcon from '@material-ui/icons/Save';
import Button from '@material-ui/core/Button';

import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import FormHelperText from '@material-ui/core/FormHelperText';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';


//Redux imports
import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'
import { setHomeRender, setRqSelected } from '../../actions'

import firebase from '../../firabase'

const useStyles = makeStyles(theme => ({
    layout: {
      width: 'auto',
      marginLeft: theme.spacing(2),
      marginRight: theme.spacing(2),
      [theme.breakpoints.up(600 + theme.spacing(2) * 2)]: {
        width: 680,
        marginLeft: 'auto',
        marginRight: 'auto',
        marginTop: "40px",
        }
    },
    paper: {
    marginTop: theme.spacing(3),
    marginBottom: theme.spacing(3),
    padding: theme.spacing(2),
    [theme.breakpoints.up(600 + theme.spacing(3) * 2)]: {
        marginTop: theme.spacing(6),
        marginBottom: theme.spacing(6),
        padding: theme.spacing(3),
        },
    },
    button: {
        margin: theme.spacing(1),
    },
    textFieldLine: {
        marginLeft: theme.spacing(1),
        marginRight: theme.spacing(1),
    },
  }));

function FormDialog(props) {
    const initialState = ""

    const [disabledProp, setDisabledProp] = React.useState(false)
    const [state, setState] = React.useState(initialState)

    const handleClose = () => {
        props.setOpen(false);
    };

    const changeOrgao = async (e) => {
        e.preventDefault()
        const db = firebase.firestore().collection("rqs").doc(props.rqSelected)
        setDisabledProp(true)

        if(state){
            await db.update({
                orgao: state
            })
            console.log('success!!')

            handleClose()
        }else{

        }
    }
    const handleChange = e =>{
        const { value } = e.target
        setState(value)
    }
    React.useEffect(()=>{
        if(props.orgao == state){
            setDisabledProp(true)
        }else{
            setDisabledProp(false)
        }

    },[state])

    React.useEffect(()=>{
        setState(props.orgao)
    },[props.orgao])

    return (
        <div>
        <Dialog open={props.open} onClose={handleClose} aria-labelledby="form-dialog-title">
            <form onSubmit={changeOrgao}>
                <DialogTitle id="form-dialog-title">Deseja alterar o orgão ?</DialogTitle>
                <DialogContent>
                <DialogContentText>
                    Digite o nome da prefeitura.
                </DialogContentText>
                
                    <TextField
                        autoFocus
                        margin="dense"
                        id="orgaoM"
                        value={state}
                        onChange={handleChange}
                        label="Orgão"
                        required
                        type="text"
                        fullWidth
                    />
                </DialogContent>
                <DialogActions>
                <Button onClick={handleClose} color="primary">
                    Cancelar
                </Button>
                <Button type="submit" color="primary" id="saveEditOrgao" disabled={disabledProp}>
                    Gravar
                </Button>
                </DialogActions>
            </form>
        </Dialog>
        </div>
    );
}
const initialState = {
    numeroDoPregao: "",
    numeroDoProcesso: "",
    abertura: null,
    modalidade: ""
}

function reducer(state, { field, value}){
    return {
        ...state,
        [field]: value
    }
}

function Edit(props){
    const classes = useStyles()

    const [open, setOpen] = useState(false)
    const [state, dispatch] = useReducer(reducer, initialState)
    const [updateButton, setUpdateButton] = useState(true)

    const handleDateChange = date => {
        dispatch({field: "abertura", value: date})
        if(updateButton) setUpdateButton(false)
    };
    
    function removeEmptyKeys(json){
        Object.keys(json).forEach(el=>{
            if(json[el] === "") delete json[el]
        })

        return json
    }

    const onChangeValue = e => {
        const { name, value } = e.target
        dispatch({field: name, value: value})
        if(updateButton) setUpdateButton(false)
    }

    const setHomeRender = () => {
        props.setHomeRender(0)
    }
    const updateRqData = async (e) => {
        e.preventDefault()
        setUpdateButton(true)
        const db = firebase.firestore().collection("rqs").doc(props.rqSelected)
        await db.update({
            ...state
        })
        console.log('updated!!')
    }
    const getRqData = async () => {
        let db = firebase.firestore()
        await db.collection("rqs").doc(props.rqSelected)
        .onSnapshot( (doc) => {
            let json = removeEmptyKeys(doc.data())
            Object.keys(json).forEach( el=> {
                if(el === "abertura"){
                    json[el] = new Date(json[el].seconds * 1000)
                }
                dispatch({field: el, value: json[el]})
                setUpdateButton(true)
            })
        })
    }
    useEffect(()=>{
        getRqData()
    },[props.rqSelected])

    const { numeroDoPregao, numeroDoProcesso, abertura, modalidade, orgao } = state
    
    return(
        <React.Fragment>
          <main className={classes.layout}>
              <Paper className={classes.paper}>
                   <FormDialog open={open} setOpen={setOpen} rqSelected={props.rqSelected} orgao={orgao}></FormDialog>
                    <Typography component="h1" variant="h5" align="left">
                        {state.orgao}
                        <Button
                            startIcon={<EditIcon fontSize="small" color="inherit"/>}
                            onClick={() => setOpen(true)}
                        >{""}
                        </Button>
                    </Typography>
                    <form onSubmit={updateRqData}>
                        <Grid container spacing={2}>
                            <Grid item xs={6}>
                                <TextField
                                    id="numeroDoPregao"
                                    label="Numero do pregão"
                                    value={numeroDoPregao}
                                    onChange={onChangeValue}
                                    margin="normal"
                                    type="text"
                                    name="numeroDoPregao"
                                    required
                                    fullWidth
                                    InputLabelProps={{
                                        shrink: true,
                                    }}
                                />
                            </Grid>
                            <Grid item xs={6}>
                                <TextField
                                    id="numeroDoProcesso"
                                    label="Numero do processo"
                                    value={numeroDoProcesso}
                                    onChange={onChangeValue}
                                    margin="normal"
                                    type="text"
                                    name="numeroDoProcesso"
                                    required
                                    fullWidth
                                    InputLabelProps={{
                                        shrink: true,
                                    }}
                                />
                            </Grid>
                        </Grid>
                            <Grid container spacing={3}>
                                <MuiPickersUtilsProvider utils={DateFnsUtils} locale={ptBR}>
                                    <Grid item xs={4}>
                                        <KeyboardDatePicker
                                            margin="normal"
                                            id="aberturaData"
                                            name="aberturaData"
                                            label="Data da abertura"
                                            format="dd/MM/yyyy"
                                            value={abertura}
                                            onChange={handleDateChange}
                                            KeyboardButtonProps={{
                                                'aria-label': 'change date',
                                            }}
                                            />
                                    </Grid>
                                    <Grid item xs={4}>
                                    <KeyboardTimePicker
                                            margin="normal"
                                            id="aberturaHora"
                                            name="aberturaHora"
                                            label="Horário da abertura"
                                            value={abertura}
                                            onChange={handleDateChange}
                                            KeyboardButtonProps={{
                                                'aria-label': 'change time',
                                            }}
                                            />
                                    </Grid>
                                </MuiPickersUtilsProvider>
                                    <Grid item xs={4}>
                                        <FormControl fullWidth margin="normal">
                                        <InputLabel id="demo-simple-select-label">Modalidade</InputLabel>
                                            <Select
                                            labelId="demo-simple-select-label"
                                            align="left"
                                            id="demo-simple-select"
                                            name="modalidade"
                                            value={modalidade}
                                            onChange={onChangeValue}
                                            >
                                                <MenuItem value="Pregão Presencial">Presencial</MenuItem>
                                                <MenuItem value="Pregão Eletrônico">Eletrônico</MenuItem>
                                            </Select>
                                        </FormControl>
                                    </Grid>
                            </Grid>
                        <Grid container spacing={1} direction="row" justify="center" alignItems="center">
                            <Grid item sx="true">
                                <Button
                                    variant="contained"
                                    color="primary"
                                    size="medium"
                                    name="aberturaHora"
                                    className={classes.button}
                                    startIcon={<SaveIcon />}
                                    type="submit"
                                    disabled={updateButton}
                                    >Salvar
                                </Button>
                                <Button
                                    variant="contained"
                                    color="secondary"
                                    size="medium"
                                    className={classes.button}
                                    startIcon={<DeleteIcon />}
                                    onClick={setHomeRender}
                                    >Cancelar
                                </Button>
                            </Grid>
                      </Grid>
                    </form>
                        </Paper>
          </main>
      </React.Fragment>
    )
}

const mapStateToProps = store => ({
    rqSelected: store.mainReducer.rqSelected
})

const mapDispatchToProps = dispatch => (
    bindActionCreators({ setRqSelected, setHomeRender }, dispatch)
)

export default connect(mapStateToProps,mapDispatchToProps)(Edit)
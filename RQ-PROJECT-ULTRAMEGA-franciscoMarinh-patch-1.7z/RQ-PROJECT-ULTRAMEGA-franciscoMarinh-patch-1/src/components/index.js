import React, { Component } from 'react';
import './App.css';
import firebase from '../../firabase'

export default class App extends Component{
  constructor() {
    super();
    this.state = {
     email: "",
     password: ""
    };
  }
  addUser = e => {
    e.preventDefault();
    const { email, password} = this.state
    firebase.auth().signInWithEmailAndPassword(email, password).catch(function(error) {
      var errorCode = error.code;
      var errorMessage = error.message;
    });
  };
  updateInput = e => {
    this.setState({
      [e.target.name]: e.target.value
    });
  }
  testeRequest(){
    const db = firebase.firestore();
    db.collection("users").doc("8V1h9vxBE14t3H14TIMo").get().then((querySnapshot) => {
          console.log(querySnapshot.data());

    });
  }
  componentDidMount(){
    const email = "franc1sc1566@gmail.com"
    const password = "12345689"
    
  }
  teste(){
    firebase.auth().onAuthStateChanged(user => {
      if(user){ //se o usuario existir
        console.log(user)
      }else{ //se não
        console.log("aquii")
      }
    })
  }
  render() {
    return (
      <div>
        <form onSubmit={this.addUser}>
        <input
          type="email"
          name="email"
          placeholder="E-mail"
          onChange={this.updateInput}
          value={this.state.email}
        />
        <input
          type="text"
          name="password"
          placeholder="Password"
          onChange={this.updateInput}
          value={this.state.password}
        />
        <button type="submit">Submit</button>
      </form>
      <button onClick={this.teste}>Teste</button>
      </div>
    );
  }
}

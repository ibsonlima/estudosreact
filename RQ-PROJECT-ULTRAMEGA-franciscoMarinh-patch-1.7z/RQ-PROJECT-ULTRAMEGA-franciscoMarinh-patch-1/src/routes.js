import {Switch, Route, BrowserRouter} from 'react-router-dom'
import React from 'react'
import Main from './pages/main'

export const Routes = () => (
    <BrowserRouter>
        <Switch>
            <Route exact path="/" component={Main}></Route>
        </Switch>
    </BrowserRouter>
)
import React from 'react';
import './App.css';
import { Routes } from './routes'

const App = () => (
  <div className="App">
    <Routes></Routes>
  </div>
)

export default App
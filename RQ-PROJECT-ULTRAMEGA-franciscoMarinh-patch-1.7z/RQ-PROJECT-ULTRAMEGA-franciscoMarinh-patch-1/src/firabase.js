import * as firebase from 'firebase/app';
import 'firebase/firestore';
import 'firebase/auth';

const firebaseConfig = {
    apiKey: "AIzaSyAX5ZV-q9Q7r2VHfwJtQALbIdcUbjKDFsw",
    authDomain: "hosting-react-with-firebase3.firebaseapp.com",
    databaseURL: "https://hosting-react-with-firebase3.firebaseio.com",
    projectId: "hosting-react-with-firebase3",
    storageBucket: "hosting-react-with-firebase3.appspot.com",
    messagingSenderId: "170242629937",
    appId: "1:170242629937:web:23d5e0c3318adcab709010",
    measurementId: "G-6111238CY4"
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);

export default firebase
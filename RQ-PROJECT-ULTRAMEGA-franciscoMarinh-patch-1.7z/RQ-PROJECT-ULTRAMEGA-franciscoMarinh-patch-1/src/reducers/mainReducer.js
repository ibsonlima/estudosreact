import { MAIN_RENDER, HOME_RENDER, RQ_SELECTED } from '../actions/mainActions'

const initialState = {
    mainRender: 0,
    homeRender: 0,
    rqSelected: null,
}

export const mainReducer = (state = initialState, action) => {
    switch (action.type) {
    
        case MAIN_RENDER:
            return{
                ...state,
                mainRender: action.mainRender
            }
        case HOME_RENDER:
            return{
                ...state,
                homeRender: action.homeRender
            }
        case RQ_SELECTED:
            return{
                ...state,
                rqSelected: action.rqSelected
            }
        default:
            return state
    }
}
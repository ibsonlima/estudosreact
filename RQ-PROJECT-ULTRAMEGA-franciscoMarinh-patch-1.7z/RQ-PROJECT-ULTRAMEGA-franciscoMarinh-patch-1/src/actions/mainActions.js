export const MAIN_RENDER = "MAIN_RENDER"
export const HOME_RENDER = "HOME_RENDER"
export const RQ_SELECTED = "RQ_SELECTED"


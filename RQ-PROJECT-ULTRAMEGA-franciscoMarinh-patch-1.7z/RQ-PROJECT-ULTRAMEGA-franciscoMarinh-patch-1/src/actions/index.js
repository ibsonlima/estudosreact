import { MAIN_RENDER, HOME_RENDER, RQ_SELECTED } from './mainActions'

export const setMainRender = value => ({
    type: MAIN_RENDER,
    mainRender: value
})

export const setHomeRender = value => ({
    type: HOME_RENDER,
    homeRender: value
})

export const setRqSelected = value => ({
    type: RQ_SELECTED,
    rqSelected: value
})
